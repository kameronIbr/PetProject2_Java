/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab07;
// MainDriver.java
// Kameron Ibraheem
// Lab07: Pet
//
//
/**
 *
 * @author kamer
 */
import java.util.ArrayList;
import java.util.Random;

public class MainDriver {
    public static void main(String[] args) {
        ArrayList<Pet> petShelter = new ArrayList<>();
        Random random = new Random();

        // populate the petShelter ArrayList with Dog, Cat, and Bird objects based on random numbers
        for (int i = 0; i < 30; i++) {
            int randNum = random.nextInt(10) + 1; // Generate a random number between 1 and 10

            if (randNum % 3 == 0) {
                petShelter.add(new Dog()); // add dog if number is divisible by 3
            } else if (randNum % 2 == 0) {
                petShelter.add(new Cat()); // add cat if number is divisible by 2 but not 3
            } else {
                petShelter.add(new Bird()); // add Bird else
                System.out.println("Added a Bird");
            }
        }

        // display info of all the Pets in the petShelter
        System.out.println("All pets in the pet shelter:");
        for (Pet pet : petShelter) {
            pet.displayInfo();
            System.out.println();
        }

        // count method
        int dogCount = 0;
        int catCount = 0;
        int birdCount = 0;

        for (Pet pet : petShelter) {
            if (pet instanceof Dog) {
                dogCount++;
            } else if (pet instanceof Cat) {
                catCount++;
            } else if (pet instanceof Bird) {
                birdCount++;
            }
        }

        System.out.println("Number of Dogs: " + dogCount);
        System.out.println("Number of Cats: " + catCount);
        System.out.println("Number of Birds: " + birdCount);
        System.out.println();

        // Display the petIDs of all cat-chasing dogs
        System.out.println("Cat-chasing Dogs:");
        for (Pet pet : petShelter) {
            if ("Dog".equals(pet.getType())) {
                Dog dog = (Dog) pet;
                if (dog.isCatChaser()) {
                    System.out.println(dog.getPetID());
                }
            }
        }
        System.out.println();

        // display the petIDs of all cats older than 10 years
        System.out.println("Cats older than 10 years:");
        for (Pet pet : petShelter) {
            if ("Cat".equals(pet.getType())) {
                Cat cat = (Cat) pet;
                if (cat.getAge() > 10) {
                    System.out.println(cat.getPetID());
                }
            }
        }
        System.out.println();

        // display the petIDs of all multi-color birds
        System.out.println("Multi-color Birds:");
        for (Pet pet : petShelter) {
            if (pet instanceof Bird) {
                Bird bird = (Bird) pet;
                if ("MULTICOLOR".equals(bird.getColor())) {
                    System.out.println(bird.getPetID());
                }
            }
        }
    }
}

