/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab07;

/**
 *
 * @author kamer
 */
// Cat.java
// Kameron Robert Ibraheem
// Lab 07: Cat
//
//

import java.util.Random;

public class Cat extends Pet {
    // Instance Variables
    private double purrVolume;
    private double meowVolume;
    private boolean declawed;

    // Constructor
    public Cat() {
        super("Cat");  // Calls the constructor of the Pet class, setting the type to "Cat"

        Random random = new Random();

        // Initialize Pet class's instance variables
        setAge(random.nextInt(39));           // Age between 0 and 38
        setHeight(8 + random.nextDouble() * 2); // Height between 8 and 10 inches
        setWeight(6 + random.nextDouble() * 6); // Weight between 6 and 12 pounds

        // Initialize Cat class's instance variables
        this.purrVolume = random.nextDouble() * 67.8;       // Purr volume between 0.0 and 67.8 dB
        this.meowVolume = this.purrVolume * 1.35;           // Meow volume is 1.35 times the purr volume
        this.declawed = random.nextBoolean();               // Randomly set declawed status
    }

    // Getters
    public double getPurrVolume() {
        return purrVolume;
    }

    public double getMeowVolume() {
        return meowVolume;
    }

    public boolean isDeclawed() {
        return declawed;
    }

    // Setters
    public void setPurrVolume(double purrVolume) {
        this.purrVolume = purrVolume;
        this.meowVolume = purrVolume * 1.35;  // Update meow volume based on purr volume
    }

    public void setMeowVolume(double meowVolume) {
        this.meowVolume = meowVolume;
    }

    public void setDeclawed(boolean declawed) {
        this.declawed = declawed;
    }

    // Instance Method
    public void displayInfo() {
        super.displayInfo();  // Call the displayInfo() method from Pet class
        System.out.println("Purr Volume: " + purrVolume);
        System.out.println("Meow Volume: " + meowVolume);
        System.out.println("Declawed: " + declawed);
    }
}

