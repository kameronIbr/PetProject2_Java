/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab07;

/**
 *
 * @author kamer
 */
// Bird.java
// Kameron Robert Ibraheem
// Lab 07: Bird
//
//
import java.util.Random;

public class Bird extends Pet {
    // instance variables
    private String color;
    private double chirpingVolume;
    private boolean flightless;

    // constructor
    public Bird() {
        super("BIRD");  // calls the constructor of the Pet class, setting the type to "BIRD"

        Random random = new Random();

        // Initialize Pet class's instance variables
        setAge(random.nextInt(84));           // Age between 0 and 83
        setHeight(2 + random.nextDouble() * 48); // Height between 2 and 50 inches
        setWeight(0.01 + random.nextDouble() * 3.49); // Weight between 0.01 and 3.5 pounds

        // Initialize Bird class's instance variables
        String[] colors = {"BROWN", "TAN", "BEIGE", "WHITE", "GRAY", "BLACK", "MULTICOLOR"};
        this.color = colors[random.nextInt(colors.length)]; // Randomly select color
        this.chirpingVolume = 65 + random.nextDouble() * 60; // Chirping volume between 65 and 125 dB
        this.flightless = random.nextBoolean();              // Randomly set flightless status
    }

    // getters
    public String getColor() {
        return color;
    }

    public double getChirpingVolume() {
        return chirpingVolume;
    }

    public boolean isFlightless() {
        return flightless;
    }

    // Setters
    public void setColor(String color) {
        this.color = color;
    }

    public void setChirpingVolume(double chirpingVolume) {
        this.chirpingVolume = chirpingVolume;
    }

    public void setFlightless(boolean flightless) {
        this.flightless = flightless;
    }

    // Instance Method
    public void displayInfo() {
        super.displayInfo();  // Call the displayInfo() method from Pet class
        System.out.println("Color: " + color);
        System.out.println("Chirping Volume: " + chirpingVolume);
        System.out.println("Flightless: " + flightless);
    }
}

