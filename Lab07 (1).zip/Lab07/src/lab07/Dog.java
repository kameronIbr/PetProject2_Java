/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab07;

/**
 *
 * @author kamer
 */
// Dog.java
// Kameron Ibraheem
// Lab 07: Dog
//
//

import java.util.Random;

public class Dog extends Pet {
    // Instance Variables
    private double barkVolume;
    private double growlVolume;
    private boolean catChaser;

    // Constructor
    public Dog() {
        super("Dog");  // Calls the constructor of the Pet class, setting the type to "Dog"

        Random random = new Random();

        // Initialize Pet class's instance variables
        setAge(random.nextInt(30));          // Age between 0 and 29
        setHeight(4 + random.nextDouble() * 36);  // Height between 4 and 40 inches
        setWeight(1 + random.nextDouble() * 342); // Weight between 1 and 343 pounds

        // Initialize Dog class's instance variables
        this.barkVolume = random.nextDouble() * 113.1;     // Bark volume between 0.0 and 113.1 dB
        this.growlVolume = this.barkVolume / 2;            // Growl volume is half of bark volume
        this.catChaser = random.nextBoolean();             // Randomly set cat chaser status
    }

    // Getters
    public double getBarkVolume() {
        return barkVolume;
    }

    public double getGrowlVolume() {
        return growlVolume;
    }

    public boolean isCatChaser() {
        return catChaser;
    }

    // Setters
    public void setBarkVolume(double barkVolume) {
        this.barkVolume = barkVolume;
        this.growlVolume = barkVolume / 2;  // Update growl volume based on bark volume
    }

    public void setGrowlVolume(double growlVolume) {
        this.growlVolume = growlVolume;
    }

    public void setCatChaser(boolean catChaser) {
        this.catChaser = catChaser;
    }

    // Instance Method
    public void displayInfo() {
        super.displayInfo();  // Call the displayInfo() method from Pet class
        System.out.println("Bark Volume: " + barkVolume);
        System.out.println("Growl Volume: " + growlVolume);
        System.out.println("Cat Chaser: " + catChaser);
    }
}

